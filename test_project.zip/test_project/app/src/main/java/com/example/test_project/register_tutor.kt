package com.example.test_project

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class register_tutor : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register_tutor)
    }
}