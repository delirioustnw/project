package com.example.project_tutorshare

import android.view.View
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main..view.*

class ViewHolder (view: View):RecyclerView.ViewHolder(view){
    val tvname = view.tv_name

}